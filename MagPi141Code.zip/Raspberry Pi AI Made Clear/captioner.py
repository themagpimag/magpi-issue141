import requests
from PIL import Image
from transformers import BlipProcessor, BlipForConditionalGeneration

# insert the path to your model's directory in both of the following lines
processor = BlipProcessor.from_pretrained("/home/pi/Software/models/blip-image-captioning-base/")
model = BlipForConditionalGeneration.from_pretrained("/home/pi/Software/models/blip-image-captioning-base/")

img_url = input("Enter JPG image URL: ") 
raw_image = Image.open(requests.get(img_url, stream=True).raw).convert('RGB')

inputs = processor(raw_image, return_tensors="pt")

out = model.generate(**inputs, max_new_tokens=1000)
print(processor.decode(out[0], skip_special_tokens=True))

from diffusers import StableDiffusionPipeline
from PIL import Image
import datetime

prompt = input("Describe the image you want: ")
negative_prompt = input("Describe traits to avoid - e.g. blurry, fused hands: ")

# insert path to Mitsua Diffusion One below
pipe = StableDiffusionPipeline.from_pretrained("/home/pi/Software/models/mitsua-diffusion-one/", low_cpu_mem_usage=True)
pipe = pipe.to("cpu")

image = pipe(prompt, negative_prompt=negative_prompt, num_inference_steps=31, width=400, height=400).images[0]

# timecode every output image so they can't overwrite each other
created = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
image.save("output-" + created + ".png")

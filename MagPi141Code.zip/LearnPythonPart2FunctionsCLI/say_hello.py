def say_hello(name="anon"):
    print(f"Hello, {name}!")

# Calling the function with a specific name
say_hello("Alice")

# Calling the function without specifying a name, which uses the default value "anon"
say_hello()

# Define a function that takes two numbers as arguments and returns their sum
def add_numbers(num1, num2):
    total = num1 + num2
    return total

# Call the function with 2 and 3 as arguments
result = add_numbers(2, 3)
print(f"The sum is: {result}")